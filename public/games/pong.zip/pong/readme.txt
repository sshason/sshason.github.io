PONG! Version 1.04d
By Sahab Yazdani

INTRODUCTION
============

Well thank you for downloading my PONG game, I hope that you will have fun with
it, after all it is THE mother of all deathmatches...  anyways since the game
is pong, the introduction will be brief.  The game is written as a test
application for my Gaming library for the DJGPP environment, but it provides
all the things that the original game had, plus a few nifty features...

KEYS
====

Well its pretty simple really, for the paddle on the left side:  A brings
the paddle up and Z brings the paddle down.  For the paddle on the right the
UP key brings the paddle up and the DOWN key brings the paddle down.  During
the game, pressing the P key pauses the game and pressing the ESC key exits
from the match.

While your at the introduction screen, you can use either the mouse or the
keytboard to set up the game.

KEYBORAD:

Pressing the S key starts a new match with the specified number of the points.
Pressing the Q key exits the program altogether (now you wounldn't want to do
this now would you???). and pressing the UP and DOWN keys changes the number
of points that must be achieved to win the match.

MOUSE:

Click the boxes (with the left button) as you would in any graphical user
interface.  If you want to change the number of points that the match goes
up to, left-clicking brings the number up and right-clicking brings the
number down.

DISTIBUTION
===========

The PONG distribution comes with several files that make it work.  The files are:

PONG.EXE		 - Executable (The Game)
SETTINGS.PNG - Settings file.  You can change some settings from here
README.1ST	 - This file. Contains some neat information
ART 			 - (Directory) Contains all the various sprites and stuff

